package com.example.myempty.morseflashlight;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "morse_flashlight_prefs";
    private static final String KEY_HIDE_WELCOME = "hide_welcome_dialog";
    private static final int REQUEST_CAMERA_PERMISSION = 100;

    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;

    private View rootFlashButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rootFlashButton = findViewById(R.id.rootFlashButton);

        setupCamera();
        setupTouchButton();

        if (!isWelcomeDialogHidden()) {
            showWelcomeDialog();
        }

        checkCameraPermission();
    }

    private void setupCamera() {
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    Boolean hasFlash = cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (hasFlash != null && hasFlash) {
                        cameraId = id;
                        break;
                    }
                }
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("ClickableViewAccessibility")
    private void setupTouchButton() {
        rootFlashButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    turnOn();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    turnOff();
                    return true;
            }
            return false;
        });
    }

    private void turnOn() {
        rootFlashButton.setBackgroundColor(getColor(R.color.white));
        setTorch(true);
    }

    private void turnOff() {
        rootFlashButton.setBackgroundColor(getColor(R.color.black));
        setTorch(false);
    }

    private void setTorch(boolean enable) {
        if (cameraManager == null || cameraId == null) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            cameraManager.setTorchMode(cameraId, enable);
            isFlashOn = enable;
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showWelcomeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_welcome, null);
        CheckBox checkBox = dialogView.findViewById(R.id.checkboxDontShow);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        dialogView.findViewById(R.id.btnContinue).setOnClickListener(v -> {
            if (checkBox.isChecked()) {
                setWelcomeDialogHidden(true);
            }
            dialog.dismiss();
        });

        dialog.show();
    }

    private boolean isWelcomeDialogHidden() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_HIDE_WELCOME, false);
    }

    private void setWelcomeDialogHidden(boolean hidden) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_HIDE_WELCOME, hidden).apply();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFlashOn) {
            turnOff();
        }
    }
}